
import VoiceRoom from './VoiceRoom/index';
export default VoiceRoom;
